
import org.example.Turner;

// Leaf.java
public class Leaf implements Turner {
    @Override
    public void turn() {
        System.out.println("Changing colors");
    }
}
