
package org.example;
// Page.java
public class Page implements Turner {
    @Override
    public void turn() {
        System.out.println("Going to the next page");
    }
}
