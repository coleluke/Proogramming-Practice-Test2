
package org.example;

public class Wheel implements Turner {
    @Override
    public void turn() {
        System.out.println("Spinning");
    }
}
