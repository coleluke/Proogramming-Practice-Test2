
package org.example;

// Turner.java
public interface Turner {
    void turn();
}
