
package org.example;

// Pancake.java
public class Pancake implements Turner {
    @Override
    public void turn() {
        System.out.println("Flipping");
    }
}
