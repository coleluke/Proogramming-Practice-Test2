package org.example;

public class IgneousRock extends Rock {
    public IgneousRock(int sampleNumber, double weight) {
        super(sampleNumber, weight);
        // Description for Igneous Rock
        this.description = "Igneous rocks are formed from the solidification of molten magma or lava.";
    }
}