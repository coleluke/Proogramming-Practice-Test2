
package org.example;

public interface Runner {
    void run();
}
