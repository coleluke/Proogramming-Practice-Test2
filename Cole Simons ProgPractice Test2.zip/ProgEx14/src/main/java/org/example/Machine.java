
package org.example;

public class Machine implements Runner {
    @Override
    public void run() {
        System.out.println("The machine is running to perform its tasks.");
    }
}
