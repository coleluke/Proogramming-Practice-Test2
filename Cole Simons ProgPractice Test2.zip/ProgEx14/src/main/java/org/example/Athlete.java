
package org.example;

public class Athlete implements Runner {
    @Override
    public void run() {
        System.out.println("The athlete is running in a marathon.");
    }
}
