package org.example;

public class PoliticalCandidate implements Runner {
    @Override
    public void run() {
        System.out.println("The political candidate is running for office.");
    }
}