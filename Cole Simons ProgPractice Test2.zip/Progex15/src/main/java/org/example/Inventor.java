
package org.example;

public record Inventor(String name, String countryOfOrigin) {
}
