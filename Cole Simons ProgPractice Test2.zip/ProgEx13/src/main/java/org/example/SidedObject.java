
package org.example;

public interface SidedObject {
    void displaySides();
}
