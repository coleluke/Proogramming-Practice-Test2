
package org.example;

public class Jupiterian extends Alien {

    // Constructor for Jupiterian
    public Jupiterian() {
        super(2, "Blue", 8); // Example values: 2 eyes, blue color, 8 limbs
    }
}
