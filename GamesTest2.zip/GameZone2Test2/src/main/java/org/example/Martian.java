
package org.example;

public class Martian extends Alien {

    // Constructor for Martian
    public Martian() {
        super(4, "Green", 6); // Example values: 4 eyes, green color, 6 limbs
    }
}
